package by.bsu.tasks.collections.read;


import by.bsu.tasks.collections.exception.FileException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileWork {
    //метод, читающий строки из файла в список
    public static List<String> readStrings(String filePath) throws FileException {
        List<String> strings = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String str = null;
            while ((str = br.readLine()) != null) {
                if (!str.isEmpty()) {
                    strings.add(str);
                }
            }
        }
        catch (IOException e) {
            throw new FileException("Error with reading from file", e);
        }
        return strings;
    }

}
