package by.bsu.tasks.collections.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class WordOperation {
    public static Set<String> toSet(List<String> list) {
        Set<String> set = new HashSet<>();

        list.forEach(line -> {
            String[] words = line.split("[!,. ?]");

            for (String word : words) {
                set.add(word.toLowerCase());
            }

        });

        return set;
    }
}
