package by.bsu.tasks.collections;

import by.bsu.tasks.collections.exception.FileException;
import by.bsu.tasks.collections.read.FileWork;
import by.bsu.tasks.collections.service.WordOperation;


import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String... args) {
        try {

            String filepath = "src\\resourses\\text.txt";

            List<String> list = FileWork.readStrings(filepath);
            Set<String> resultSet = WordOperation.toSet(list);
            System.out.println(resultSet);
        }
        catch (FileException e){
            e.printStackTrace();
        }

    }
}
